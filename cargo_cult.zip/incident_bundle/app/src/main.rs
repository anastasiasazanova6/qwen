use std::io::{self, BufRead};

fn classify(line: &str) -> &'static str {
    if line.contains("crow") || line.contains("crate") || line.contains("mirror") {
        "route=crow-cargo"
    } else if line.contains("cargo") {
        "route=build"
    } else {
        "route=general"
    }
}

fn main() {
    let stdin = io::stdin();
    for line in stdin.lock().lines().map_while(Result::ok) {
        let cleaned = line.trim().replace('\t', " ");
        println!("{} {}", classify(&cleaned), cleaned);
    }
}
