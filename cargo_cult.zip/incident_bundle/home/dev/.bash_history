cd ~/work/crow-cargo-router
git status
cargo fmt
cargo update
cat .cargo/config.toml
cargo build -vv 2>&1 | tee ../ci/cargo_build_verbose.log
ls ~/.cargo/registry/src
ls ~/.cargo/registry/src/mgu-cargo-cult-mirror-8f3a1c2d
rg "stage|warning|index_fragment" ~/.cargo/registry/src ~/.cargo/registry/index
curl -I https://internal-mirror.local/api/v1/cache/report
rg "crow|crate|spire" src ~/.cargo/registry/index
rm -rf target/release/incremental
cargo build --release -vv
