pub fn normalize_target(input: &str) -> String {
    input.trim().replace('\t', " ").to_ascii_lowercase()
}

pub fn span_name(component: &str) -> String {
    format!("crow_cargo.{component}")
}
