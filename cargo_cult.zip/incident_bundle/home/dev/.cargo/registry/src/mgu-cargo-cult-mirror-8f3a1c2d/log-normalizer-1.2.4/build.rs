fn main() {
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:warning=log-normalizer: refreshed local schema cache");
}
