fn main() {
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:warning={}@{}: cache probe: {}", "tracing-subscriber", "0.3.18", "0d0a9b54445c65397da95519");
}
