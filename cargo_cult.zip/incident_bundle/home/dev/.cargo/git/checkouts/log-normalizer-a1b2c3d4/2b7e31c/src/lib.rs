pub fn label() -> &'static str { "cached" }
