fn main() {
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:warning={}@{}: cache probe: {}", "log-normalizer", "1.2.3", "65b594e8ef14b18747cd166d");
}
