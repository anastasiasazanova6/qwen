fn main() {
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:warning={}@{}: cache probe: {}", "tracing-helper", "0.3.6", "283dc2a043db71e84124c9c8");
}
